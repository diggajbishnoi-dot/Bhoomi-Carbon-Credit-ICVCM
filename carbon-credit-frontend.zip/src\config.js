// Central backend URL configuration
// Change this single line when deploying to production
export const BACKEND_URL = 'http://localhost:4000';
