import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Buyer from './pages/Buyer';
import Seller from './pages/Seller';
import MarketPrices from './pages/MarketPrices';
import BrowseCredits from './pages/BrowseCredits';
import WhatIsCarbonCredit from './pages/WhatIsCarbonCredit';
import Greenwashing from './pages/Greenwashing';
import PricingExplained from './pages/PricingExplained';

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/buyer" element={<Buyer />} />
        <Route path="/seller" element={<Seller />} />
        <Route path="/market-prices" element={<MarketPrices />} />
        <Route path="/browse-credits" element={<BrowseCredits />} />
        <Route path="/what-is-carbon-credit" element={<WhatIsCarbonCredit />} />
        <Route path="/greenwashing" element={<Greenwashing />} />
        <Route path="/pricing-explained" element={<PricingExplained />} />
      </Routes>
    </Layout>
  );
}
