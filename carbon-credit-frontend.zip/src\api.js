import { BACKEND_URL } from './config';

/**
 * Fallback sample data to provide a seamless developer & demo experience
 * if the backend server is not currently running locally.
 */
const MOCK_LISTINGS = [
  {
    id: "cc-101",
    project_name: "Cauvery Delta Soil Carbon Enrichment",
    project_type: "Biochar",
    registry: "Puro.earth",
    vintage_year: 2024,
    credits_issued: 14500,
    verification_status: "verified",
    methodology: "Puro Biochar Standard v2.1",
    quality_score: 92,
    quality_badge: "green",
    benchmark_price: 135.00,
    quality_multiplier: 1.15,
    fair_price: 155.25,
    fair_price_low: 148.00,
    fair_price_high: 165.00,
    quality_breakdown: [
      { rule: "Verified standard registry (+2)", points: 2 },
      { rule: "Permanent geological/biochar storage bonus (+1)", points: 1 },
      { rule: "Recent vintage <= 3 years (+1)", points: 1 },
      { rule: "Third-party audit complete (+1)", points: 1 }
    ],
    anomaly_risk_score: null,
    is_anomaly: false,
    source: "Puro.earth Registry",
    created_at: new Date().toISOString()
  },
  {
    id: "cc-102",
    project_name: "Western Ghats Agroforestry Restoration",
    project_type: "ARR",
    registry: "Gold Standard",
    vintage_year: 2023,
    credits_issued: 38000,
    verification_status: "verified",
    methodology: "GS TPDD Afforestation/Reforestation v3",
    quality_score: 84,
    quality_badge: "green",
    benchmark_price: 42.00,
    quality_multiplier: 1.05,
    fair_price: 44.10,
    fair_price_low: 40.00,
    fair_price_high: 48.50,
    quality_breakdown: [
      { rule: "Gold Standard Verified Registry (+2)", points: 2 },
      { rule: "High community biodiversity co-benefits (+1)", points: 1 },
      { rule: "Forestry permanence risk deduction (-1)", points: -1 },
      { rule: "Rigorous digital MRV satellite monitoring (+1)", points: 1 }
    ],
    anomaly_risk_score: 12,
    is_anomaly: false,
    source: "Gold Standard Registry",
    created_at: new Date().toISOString()
  },
  {
    id: "cc-103",
    project_name: "Sundarbans Coastal Mangrove Conservation",
    project_type: "REDD+",
    registry: "Verra (VCS)",
    vintage_year: 2022,
    credits_issued: 65000,
    verification_status: "verified",
    methodology: "VM0007 REDD+ Methodology Framework",
    quality_score: 71,
    quality_badge: "yellow",
    benchmark_price: 28.00,
    quality_multiplier: 0.90,
    fair_price: 25.20,
    fair_price_low: 22.00,
    fair_price_high: 29.00,
    quality_breakdown: [
      { rule: "Verra Verified Registry (+2)", points: 2 },
      { rule: "Forestry permanence buffer pool active (+0)", points: 0 },
      { rule: "Forestry/REDD+ permanence baseline uncertainty (-1)", points: -1 },
      { rule: "Vintage > 3 years old (-0.5)", points: -0.5 }
    ],
    anomaly_risk_score: 38,
    is_anomaly: false,
    source: "Verra Registry",
    created_at: new Date().toISOString()
  },
  {
    id: "cc-104",
    project_name: "Thar Desert Solar Grid Feed-in 2017",
    project_type: "IFM",
    registry: "Clean Development Mechanism (CDM)",
    vintage_year: 2017,
    credits_issued: 250000,
    verification_status: "unverified",
    methodology: "ACM0002 Grid Connected Electricity",
    quality_score: 32,
    quality_badge: "red",
    benchmark_price: 18.00,
    quality_multiplier: 0.45,
    fair_price: 8.10,
    fair_price_low: 6.50,
    fair_price_high: 10.00,
    quality_breakdown: [
      { rule: "Unverified / Non-ICVCM registry status (-2)", points: -2 },
      { rule: "Legacy renewable-energy methodology with zero additionality (-1)", points: -1 },
      { rule: "Vintage > 5 years old (-1)", points: -1 },
      { rule: "No permanence guarantees (-1)", points: -1 }
    ],
    anomaly_risk_score: 87,
    is_anomaly: true,
    source: "Legacy Registry",
    created_at: new Date().toISOString()
  },
  {
    id: "cc-105",
    project_name: "Nordic Basalt Enhanced Rock Weathering",
    project_type: "ERW",
    registry: "Puro.earth",
    vintage_year: 2024,
    credits_issued: 8500,
    verification_status: "verified",
    methodology: "Puro ERW Standard v1.2",
    quality_score: 95,
    quality_badge: "green",
    benchmark_price: 180.00,
    quality_multiplier: 1.22,
    fair_price: 219.60,
    fair_price_low: 210.00,
    fair_price_high: 235.00,
    quality_breakdown: [
      { rule: "Puro.earth Verified Standard (+2)", points: 2 },
      { rule: "10,000+ year mineral storage permanence (+1)", points: 1 },
      { rule: "Ultra-recent 2024 vintage (+1)", points: 1 },
      { rule: "Rigorous isotopic soil test verification (+1)", points: 1 }
    ],
    anomaly_risk_score: 5,
    is_anomaly: false,
    source: "Puro.earth",
    created_at: new Date().toISOString()
  },
  {
    id: "cc-106",
    project_name: "Direct Air Carbon Mineralization Alpha",
    project_type: "DAC",
    registry: "Puro.earth",
    vintage_year: 2024,
    credits_issued: 3200,
    verification_status: "verified",
    methodology: "DACCS Deep Well Solidification",
    quality_score: 98,
    quality_badge: "green",
    benchmark_price: 520.00,
    quality_multiplier: 1.25,
    fair_price: 650.00,
    fair_price_low: 620.00,
    fair_price_high: 690.00,
    quality_breakdown: [
      { rule: "Top Tier Verification Registry (+2)", points: 2 },
      { rule: "Direct Air Capture permanent storage bonus (+1)", points: 1 },
      { rule: "Zero reversal risk geological basalt mineralization (+1)", points: 1 },
      { rule: "100% additionality guarantee (+1)", points: 1 }
    ],
    anomaly_risk_score: null,
    is_anomaly: false,
    source: "Direct Registry",
    created_at: new Date().toISOString()
  },
  {
    id: "cc-107",
    project_name: "Unregistered Private Farm Land Methane Capture",
    project_type: "ARR",
    registry: "Self-Declared / Pending",
    vintage_year: 2018,
    credits_issued: 890000,
    verification_status: "unverified",
    methodology: "Custom In-House Spreadsheet",
    quality_score: 24,
    quality_badge: "red",
    benchmark_price: 15.00,
    quality_multiplier: 0.35,
    fair_price: 5.25,
    fair_price_low: 3.50,
    fair_price_high: 7.00,
    quality_breakdown: [
      { rule: "Unverified registry (-2)", points: -2 },
      { rule: "Non-standard custom methodology (-1)", points: -1 },
      { rule: "Vintage > 5 years old (-1)", points: -1 },
      { rule: "Statistical volume anomaly detected (-1)", points: -1 }
    ],
    anomaly_risk_score: 94,
    is_anomaly: true,
    source: "Unregistered",
    created_at: new Date().toISOString()
  }
];

const MOCK_COMPANIES = {
  "reliance": {
    company_name: "Reliance Industries",
    sector: "Energy & Petrochemicals",
    required_credits: 45000,
    current_holdings: 18500
  },
  "tata steel": {
    company_name: "Tata Steel",
    sector: "Heavy Manufacturing & Metallurgy",
    required_credits: 60000,
    current_holdings: 22000
  },
  "infosys": {
    company_name: "Infosys",
    sector: "Technology & Cloud Services",
    required_credits: 12000,
    current_holdings: 15000
  },
  "mahindra": {
    company_name: "Mahindra & Mahindra",
    sector: "Automotive & Farm Equipment",
    required_credits: 30000,
    current_holdings: 14000
  },
  "itc": {
    company_name: "ITC Limited",
    sector: "Agriculture & FMCG",
    required_credits: 20000,
    current_holdings: 19500
  }
};

/**
 * 1. GET /credits?project_type=&quality_badge=&registry=
 */
export async function getCredits(params = {}) {
  const query = new URLSearchParams();
  if (params.project_type) query.append('project_type', params.project_type);
  if (params.quality_badge) query.append('quality_badge', params.quality_badge);
  if (params.registry) query.append('registry', params.registry);

  const url = `${BACKEND_URL}/credits${query.toString() ? `?${query.toString()}` : ''}`;
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn(`[API] getCredits live fetch failed (${err.message}). Using fallback data.`);
    let filtered = [...MOCK_LISTINGS];
    if (params.project_type) {
      filtered = filtered.filter(item => item.project_type.toLowerCase() === params.project_type.toLowerCase());
    }
    if (params.quality_badge) {
      filtered = filtered.filter(item => item.quality_badge.toLowerCase() === params.quality_badge.toLowerCase());
    }
    if (params.registry) {
      filtered = filtered.filter(item => item.registry.toLowerCase().includes(params.registry.toLowerCase()));
    }
    return {
      count: filtered.length,
      listings: filtered
    };
  }
}

/**
 * 2. POST /credits/list-credit
 * body: {project_name, project_type, registry, vintage_year, credits_issued, verification_status, methodology}
 */
export async function listCredit(creditData) {
  const url = `${BACKEND_URL}/credits/list-credit`;
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(creditData)
    });
    if (!res.ok) {
      const errorBody = await res.json().catch(() => ({}));
      throw new Error(errorBody.message || `Server responded with ${res.status}`);
    }
    return await res.json();
  } catch (err) {
    console.warn(`[API] listCredit live fetch failed (${err.message}). Simulating calculation engine.`);
    
    // Simulate scoring algorithm locally if offline
    let score = 50;
    const breakdown = [];
    
    // Registry check
    const isStandardRegistry = ['verra', 'gold standard', 'puro.earth', 'puro', 'acr', 'car'].some(r => 
      (creditData.registry || '').toLowerCase().includes(r)
    );
    if (isStandardRegistry && creditData.verification_status === 'verified') {
      score += 25;
      breakdown.push({ rule: "Verified standard registry (+2)", points: 2 });
    } else if (creditData.verification_status === 'unverified') {
      score -= 20;
      breakdown.push({ rule: "Unverified or unaccredited registry (-2)", points: -2 });
    }

    // Methodology check
    if ((creditData.methodology || '').toLowerCase().includes('renewable') || (creditData.methodology || '').toLowerCase().includes('solar')) {
      score -= 15;
      breakdown.push({ rule: "Legacy renewable-energy methodology with low additionality (-1)", points: -1 });
    }

    // Vintage year check
    const currentYear = new Date().getFullYear();
    const age = currentYear - parseInt(creditData.vintage_year || currentYear, 10);
    if (age > 5) {
      score -= 15;
      breakdown.push({ rule: "Vintage > 5 years old (-1)", points: -1 });
    } else if (age <= 2) {
      score += 10;
      breakdown.push({ rule: "Fresh vintage <= 2 years old (+1)", points: 1 });
    }

    // Project Type Bonus/Penalty
    if (['DAC', 'Biochar', 'ERW'].includes(creditData.project_type)) {
      score += 15;
      breakdown.push({ rule: "Permanent carbon removal & durable storage bonus (+1)", points: 1 });
    } else if (['REDD+', 'ARR', 'IFM'].includes(creditData.project_type)) {
      breakdown.push({ rule: "Nature-based biological storage permanence risk (-1)", points: -1 });
    }

    // Determine badge & multiplier
    score = Math.max(10, Math.min(99, score));
    let badge = 'yellow';
    let multiplier = 1.0;
    let benchmark = 35.0;

    if (creditData.project_type === 'DAC') benchmark = 500.0;
    else if (creditData.project_type === 'Biochar' || creditData.project_type === 'ERW') benchmark = 140.0;
    else if (creditData.project_type === 'ARR') benchmark = 42.0;
    else if (creditData.project_type === 'REDD+') benchmark = 28.0;
    else benchmark = 20.0;

    if (score >= 80) {
      badge = 'green';
      multiplier = 1.15;
    } else if (score >= 50) {
      badge = 'yellow';
      multiplier = 0.90;
    } else {
      badge = 'red';
      multiplier = 0.50;
    }

    const fairPrice = +(benchmark * multiplier).toFixed(2);
    const low = +(fairPrice * 0.92).toFixed(2);
    const high = +(fairPrice * 1.10).toFixed(2);

    const newId = `cc-${Date.now().toString().slice(-4)}`;
    const newRecord = {
      id: newId,
      ...creditData,
      quality_score: score,
      quality_badge: badge,
      benchmark_price: benchmark,
      quality_multiplier: multiplier,
      fair_price: fairPrice,
      fair_price_low: low,
      fair_price_high: high,
      quality_breakdown: breakdown,
      anomaly_risk_score: creditData.credits_issued > 500000 && creditData.verification_status === 'unverified' ? 88 : null,
      is_anomaly: creditData.credits_issued > 500000 && creditData.verification_status === 'unverified',
      source: 'Farmer / Developer Submission',
      created_at: new Date().toISOString()
    };

    MOCK_LISTINGS.unshift(newRecord);

    return {
      success: true,
      id: newId,
      pricing: {
        quality_score: score,
        quality_badge: badge,
        benchmark_price: benchmark,
        quality_multiplier: multiplier,
        fair_price: fairPrice,
        fair_price_low: low,
        fair_price_high: high,
        quality_breakdown: breakdown,
        is_anomaly: newRecord.is_anomaly,
        anomaly_risk_score: newRecord.anomaly_risk_score
      }
    };
  }
}

/**
 * 3. GET /price-index
 */
export async function getPriceIndex() {
  const url = `${BACKEND_URL}/price-index`;
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn(`[API] getPriceIndex live fetch failed (${err.message}). Using simulated EU ETS feed.`);
    return {
      count: 3,
      price_index: [
        {
          tier: "EU_ETS_ALLOWANCE",
          label: "EU ETS Compliance Carbon (EUA)",
          price: 68.45,
          currency: "EUR",
          fetched_at: new Date().toISOString()
        },
        {
          tier: "GLOBAL_VCM_REMOVAL",
          label: "Global Durable Carbon Removal Index",
          price: 142.80,
          currency: "USD",
          fetched_at: new Date().toISOString()
        },
        {
          tier: "NATURE_BASED_ACC",
          label: "Nature-Based Avoidance & ARR Index",
          price: 31.20,
          currency: "USD",
          fetched_at: new Date().toISOString()
        }
      ]
    };
  }
}

/**
 * 4. GET /companies/:name
 */
export async function getCompany(name) {
  const encoded = encodeURIComponent(name.trim());
  const url = `${BACKEND_URL}/companies/${encoded}`;
  try {
    const res = await fetch(url);
    if (res.status === 404) return null;
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn(`[API] getCompany live fetch failed (${err.message}). Checking mock database.`);
    const key = name.trim().toLowerCase();
    const matched = Object.entries(MOCK_COMPANIES).find(([k]) => key.includes(k) || k.includes(key));
    if (matched) return matched[1];
    return null;
  }
}

/**
 * 5. POST /companies/optimize
 * body: { company_name }
 */
export async function optimizeCompany(companyName) {
  const url = `${BACKEND_URL}/companies/optimize`;
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ company_name: companyName })
    });
    if (res.status === 404) {
      const errObj = new Error('Company not found');
      errObj.status = 404;
      throw errObj;
    }
    if (!res.ok) {
      const errorBody = await res.json().catch(() => ({}));
      throw new Error(errorBody.message || `HTTP ${res.status}`);
    }
    return await res.json();
  } catch (err) {
    if (err.status === 404) throw err;
    console.warn(`[API] optimizeCompany live fetch failed (${err.message}). Computing optimization locally.`);
    
    const key = companyName.trim().toLowerCase();
    const matchedEntry = Object.entries(MOCK_COMPANIES).find(([k]) => key.includes(k) || k.includes(key));
    
    if (!matchedEntry) {
      const notFoundErr = new Error("This company isn't in our database yet");
      notFoundErr.status = 404;
      throw notFoundErr;
    }

    const comp = matchedEntry[1];
    const gap = Math.max(0, comp.required_credits - comp.current_holdings);

    if (gap <= 0) {
      return {
        company: comp,
        gap: 0,
        optimization: {
          selected_listings: [],
          total_credits_filled: 0,
          total_cost: 0,
          avg_quality_score: 100,
          shortfall: 0
        }
      };
    }

    // Optimize selection favoring high quality credits
    let remainingGap = gap;
    const selected = [];
    let totalCost = 0;
    let qualityPointsSum = 0;

    // Filter available listings with positive credits
    const available = MOCK_LISTINGS.filter(l => l.quality_badge !== 'red');
    for (const listing of available) {
      if (remainingGap <= 0) break;
      const take = Math.min(remainingGap, listing.credits_issued);
      if (take > 0) {
        selected.push({
          ...listing,
          credits_taken: take,
          item_total: +(take * listing.fair_price).toFixed(2)
        });
        totalCost += take * listing.fair_price;
        qualityPointsSum += listing.quality_score * take;
        remainingGap -= take;
      }
    }

    const totalCreditsFilled = gap - remainingGap;
    const avgScore = totalCreditsFilled > 0 ? Math.round(qualityPointsSum / totalCreditsFilled) : 0;

    return {
      company: comp,
      gap: gap,
      optimization: {
        selected_listings: selected,
        total_credits_filled: totalCreditsFilled,
        total_cost: +totalCost.toFixed(2),
        avg_quality_score: avgScore,
        shortfall: remainingGap
      }
    };
  }
}
