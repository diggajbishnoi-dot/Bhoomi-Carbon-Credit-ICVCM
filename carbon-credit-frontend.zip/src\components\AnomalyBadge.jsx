import React from 'react';
import { ShieldAlert, Sparkles } from 'lucide-react';
import { useTranslation } from '../i18n/I18nContext';

/**
 * AnomalyBadge Component
 * Visually distinct from the green/yellow/red QualityBadge system.
 * Uses a deep indigo/violet theme to warn about statistical anomalies
 * detected by the unsupervised Isolation Forest machine learning model.
 */
export default function AnomalyBadge({ riskScore = null, compact = false }) {
  const { t } = useTranslation();

  return (
    <div
      title={t('anomaly.badge_desc')}
      className={`inline-flex items-center gap-2 rounded-lg border border-purple-300 bg-purple-50/90 text-purple-900 shadow-sm backdrop-blur-sm transition-all hover:bg-purple-100/90 ${
        compact ? 'px-2.5 py-1 text-xs' : 'px-3 py-1.5 text-xs sm:text-sm'
      }`}
    >
      <div className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-purple-200 text-purple-700">
        <ShieldAlert size={13} />
      </div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:gap-2">
        <span className="font-semibold text-purple-950">
          Statistical Anomaly — unusual profile, review recommended
        </span>
        {riskScore !== null && (
          <span className="inline-flex items-center rounded bg-purple-200/80 px-1.5 py-0.5 text-[11px] font-bold text-purple-900">
            {t('anomaly.risk_score', { score: riskScore })}
          </span>
        )}
      </div>
    </div>
  );
}
