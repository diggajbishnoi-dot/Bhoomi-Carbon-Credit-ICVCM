import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Leaf, Globe, ChevronDown, IndianRupee, DollarSign, Sparkles } from 'lucide-react';
import { useTranslation, LANGUAGES } from '../i18n/I18nContext';
import { useCurrency } from '../utils/currency';

export default function Navbar() {
  const { t, language, setLanguage } = useTranslation();
  const { currency, setCurrency } = useCurrency();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);

  const navLinks = [
    { to: '/', label: t('nav.home') },
    { to: '/buyer', label: t('nav.buyer') },
    { to: '/seller', label: t('nav.seller') },
    { to: '/market-prices', label: t('nav.market_prices') },
    { to: '/browse-credits', label: t('nav.browse_credits') },
    { to: '/what-is-carbon-credit', label: t('nav.what_is_carbon') },
    { to: '/greenwashing', label: t('nav.greenwashing') },
    { to: '/pricing-explained', label: t('nav.pricing_explained') },
  ];

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-forest-100 bg-[#FAF8F5]/95 backdrop-blur-md transition-all shadow-sm">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8 h-16 sm:h-20">
        
        {/* Brand Logo */}
        <Link to="/" className="flex items-center gap-3 group">
          <div className="relative flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-forest-800 to-forest-950 text-white shadow-md shadow-forest-950/20 group-hover:scale-105 transition-transform">
            <Leaf size={22} className="text-emerald-300 animate-pulse-subtle" />
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-display text-xl sm:text-2xl font-extrabold tracking-tight text-forest-950 leading-none">
                {t('nav.brand')}
              </span>
              <span className="text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded tracking-wider">
                India
              </span>
            </div>
            <span className="text-[11px] font-medium tracking-wide text-forest-700 mt-0.5">
              {t('nav.tagline')}
            </span>
          </div>
        </Link>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center gap-1">
          {navLinks.map((link) => {
            const active = isActive(link.to);
            return (
              <Link
                key={link.to}
                to={link.to}
                className={`relative px-3 py-1.5 rounded-xl text-xs lg:text-sm font-medium transition-all ${
                  active
                    ? 'text-forest-950 font-bold bg-forest-100/90 shadow-sm'
                    : 'text-slate-700 hover:text-forest-900 hover:bg-forest-50/70'
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        {/* Right Section: Currency Switcher (₹ INR / $ USD) + Language Switcher */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Currency Toggle (₹ INR / $ USD) */}
          <div className="flex items-center bg-sand-200/90 p-0.5 rounded-xl border border-sand-300 shadow-inner">
            <button
              onClick={() => setCurrency('INR')}
              className={`flex items-center gap-0.5 px-2 py-1 text-xs font-bold rounded-lg transition-all ${
                currency === 'INR'
                  ? 'bg-forest-800 text-white shadow-sm'
                  : 'text-slate-700 hover:text-forest-900'
              }`}
              title="Switch to Indian Rupee (INR)"
            >
              <span>₹ INR</span>
            </button>
            <button
              onClick={() => setCurrency('USD')}
              className={`flex items-center gap-0.5 px-2 py-1 text-xs font-bold rounded-lg transition-all ${
                currency === 'USD'
                  ? 'bg-forest-800 text-white shadow-sm'
                  : 'text-slate-700 hover:text-forest-900'
              }`}
              title="Switch to US Dollar (USD)"
            >
              <span>$ USD</span>
            </button>
          </div>

          {/* Quick Language Switcher Pills */}
          <div className="relative">
            <div className="hidden sm:flex items-center bg-sand-200/90 p-0.5 rounded-xl border border-sand-300 shadow-inner">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setLanguage(lang.code)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-all ${
                    language === lang.code
                      ? 'bg-forest-800 text-white shadow-sm'
                      : 'text-slate-700 hover:text-forest-900'
                  }`}
                >
                  {lang.nativeLabel}
                </button>
              ))}
            </div>

            {/* Mobile Language Button */}
            <div className="sm:hidden relative">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="flex items-center gap-1 rounded-xl border border-sand-300 bg-sand-100 px-2.5 py-1.5 text-xs font-bold text-forest-900 shadow-sm"
              >
                <Globe size={13} className="text-forest-700" />
                <span>{LANGUAGES.find((l) => l.code === language)?.nativeLabel}</span>
                <ChevronDown size={12} />
              </button>

              {langDropdownOpen && (
                <div className="absolute right-0 mt-1 w-32 rounded-2xl bg-white p-1.5 shadow-xl border border-slate-200 z-50">
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        setLangDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 text-xs rounded-xl font-medium transition-colors ${
                        language === lang.code
                          ? 'bg-forest-50 text-forest-900 font-bold'
                          : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {lang.nativeLabel} ({lang.label})
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Mobile Hamburger Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden rounded-xl p-2 text-slate-700 hover:bg-forest-50 hover:text-forest-900 transition-colors"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

      </div>

      {/* Mobile Slide-down Navigation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="xl:hidden border-t border-forest-100 bg-[#FAF8F5] px-4 py-4 sm:px-6 shadow-xl overflow-hidden"
          >
            <div className="flex flex-col gap-1.5">
              {navLinks.map((link) => {
                const active = isActive(link.to);
                return (
                  <Link
                    key={link.to}
                    to={link.to}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center justify-between px-4 py-3 rounded-xl text-sm font-semibold transition-colors ${
                      active
                        ? 'bg-forest-100 text-forest-950 font-bold'
                        : 'text-slate-700 hover:bg-forest-50'
                    }`}
                  >
                    <span>{link.label}</span>
                    {active && <span className="h-2 w-2 rounded-full bg-forest-700"></span>}
                  </Link>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
