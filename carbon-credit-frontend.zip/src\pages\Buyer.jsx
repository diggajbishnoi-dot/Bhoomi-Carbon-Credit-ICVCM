import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Building2, 
  Search, 
  CheckCircle2, 
  AlertCircle, 
  ShoppingBag, 
  Sparkles, 
  ArrowRight, 
  TrendingUp, 
  BotOff,
  FileDown,
  ShieldCheck,
  Award
} from 'lucide-react';
import { optimizeCompany } from '../api';
import QualityBadge from '../components/QualityBadge';
import AnomalyBadge from '../components/AnomalyBadge';
import { useTranslation } from '../i18n/I18nContext';
import { useCurrency } from '../utils/currency';

export default function Buyer() {
  const { t } = useTranslation();
  const { formatPrice, currency } = useCurrency();

  const [companyInput, setCompanyInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [errorStatus, setErrorStatus] = useState(null);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!companyInput.trim()) return;

    setLoading(true);
    setErrorStatus(null);
    setResult(null);

    try {
      const data = await optimizeCompany(companyInput.trim());
      setResult(data);
    } catch (err) {
      console.warn('[Buyer] optimize error:', err);
      if (err.status === 404 || err.message?.includes('not found') || err.message?.includes('database')) {
        setErrorStatus(404);
      } else {
        setErrorStatus(500);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleQuickSelect = (name) => {
    setCompanyInput(name);
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8 pb-24">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-1.5 rounded-full bg-forest-50 px-4 py-1 text-xs font-bold text-forest-800 border border-forest-200 mb-4">
          <Building2 size={15} className="text-forest-700" />
          <span>Corporate Net-Zero & ESG Compliance Hub</span>
        </div>
        <h1 className="font-display text-3xl sm:text-5xl font-extrabold tracking-tight text-forest-950">
          {t('buyer.title')}
        </h1>
        <p className="mt-3 text-sm sm:text-base text-slate-600 font-medium">
          {t('buyer.subtitle')}
        </p>
      </div>

      {/* STEP 1: COMPANY SEARCH INPUT */}
      <div className="max-w-2xl mx-auto mb-12">
        <form onSubmit={handleSearch} className="relative flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input
              type="text"
              value={companyInput}
              onChange={(e) => setCompanyInput(e.target.value)}
              placeholder={t('buyer.search_placeholder')}
              className="w-full rounded-2xl border border-sand-300 bg-white py-4 pl-12 pr-4 text-base font-bold text-slate-900 shadow-sm transition-all focus:border-forest-600 focus:outline-none focus:ring-4 focus:ring-forest-100 placeholder:text-slate-400"
            />
          </div>

          <button
            type="submit"
            disabled={loading || !companyInput.trim()}
            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-forest-800 px-7 py-4 text-base font-bold text-white shadow-lg shadow-forest-950/20 hover:bg-forest-900 focus:outline-none focus:ring-4 focus:ring-forest-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0"
          >
            {loading ? (
              <span>{t('buyer.searching')}</span>
            ) : (
              <>
                <span>{t('buyer.search_btn')}</span>
                <ArrowRight size={18} />
              </>
            )}
          </button>
        </form>

        {/* Quick Suggestion Chips */}
        <div className="mt-3 flex items-center gap-2 text-xs text-slate-500 flex-wrap">
          <span className="font-bold">Index Data Available:</span>
          {['Reliance', 'Tata Steel', 'Infosys', 'Mahindra', 'ITC'].map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => handleQuickSelect(name)}
              className="rounded-xl bg-sand-100 px-3 py-1.5 text-slate-700 hover:bg-forest-100 hover:text-forest-900 transition-colors border border-sand-200 font-bold"
            >
              {name}
            </button>
          ))}
        </div>
      </div>

      {/* STEP 5: 404 / COMPANY NOT FOUND STATE */}
      {errorStatus === 404 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-2xl mx-auto rounded-3xl border border-sand-300 bg-white p-8 sm:p-10 text-center shadow-sm"
        >
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 mb-4 border border-amber-200">
            <AlertCircle size={28} />
          </div>
          <h3 className="font-display text-2xl font-bold text-slate-900">
            {t('buyer.not_found_title')}
          </h3>
          <p className="mt-2 text-sm text-slate-600 max-w-md mx-auto leading-relaxed font-medium">
            {t('buyer.not_found_desc')}
          </p>

          <div className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-slate-100 px-4 py-2.5 text-xs font-bold text-slate-400 border border-slate-200 cursor-not-allowed select-none">
            <BotOff size={15} />
            <span>{t('buyer.ai_lookup_coming_soon')}</span>
          </div>
        </motion.div>
      )}

      {/* STEP 2 & 3: SUCCESSFUL OPTIMIZATION RESULT */}
      {result && result.company && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="space-y-8"
        >
          {/* STEP 2: COMPANY LIABILITY & PROGRESS GAP INDICATOR */}
          <div className="rounded-3xl border border-sand-300 bg-white p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-100 pb-6">
              <div>
                <span className="text-xs font-extrabold uppercase tracking-wider text-forest-800 bg-forest-50 px-3 py-1 rounded-lg border border-forest-200">
                  {result.company.sector}
                </span>
                <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
                  {result.company.company_name}
                </h2>
              </div>

              <div className="flex items-center gap-5">
                <div className="text-right">
                  <div className="text-xs font-bold text-slate-500 uppercase">{t('buyer.need_credits')}</div>
                  <div className="font-display text-xl sm:text-2xl font-extrabold text-slate-900">
                    {(result.company.required_credits || 0).toLocaleString()} t
                  </div>
                </div>
                <div className="h-9 w-px bg-slate-200" />
                <div className="text-right">
                  <div className="text-xs font-bold text-slate-500 uppercase">{t('buyer.have_credits')}</div>
                  <div className="font-display text-xl sm:text-2xl font-extrabold text-forest-700">
                    {(result.company.current_holdings || 0).toLocaleString()} t
                  </div>
                </div>
              </div>
            </div>

            {/* Gap Progress Visual Bar */}
            <div className="mt-6">
              {result.gap <= 0 ? (
                /* Clear Success State: Requirement Already Met */
                <div className="rounded-3xl bg-emerald-50 border border-emerald-200 p-6 sm:p-8 text-center">
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 mb-3">
                    <CheckCircle2 size={30} />
                  </div>
                  <h3 className="font-display text-2xl font-bold text-emerald-950">
                    {t('buyer.met_requirement_title')}
                  </h3>
                  <p className="mt-2 text-sm text-emerald-800 max-w-lg mx-auto font-medium">
                    {t('buyer.met_requirement_desc', {
                      holdings: (result.company.current_holdings || 0).toLocaleString(),
                      target: (result.company.required_credits || 0).toLocaleString()
                    })}
                  </p>
                </div>
              ) : (
                /* Active Procurement Gap Progress Bar */
                <div>
                  <div className="flex justify-between text-xs sm:text-sm font-bold mb-2 flex-wrap gap-2">
                    <span className="text-slate-700">
                      You need <strong className="text-slate-900">{result.company.required_credits.toLocaleString()}</strong> credits — you currently have <strong className="text-forest-700">{result.company.current_holdings.toLocaleString()}</strong>
                    </span>
                    <span className="text-rose-700 font-extrabold">
                      {t('buyer.gap_label')}: {result.gap.toLocaleString()} tCO2e
                    </span>
                  </div>

                  <div className="h-4 w-full rounded-full bg-slate-100 overflow-hidden p-0.5 border border-slate-200">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-forest-600 to-emerald-500 transition-all duration-700"
                      style={{
                        width: `${Math.min(
                          100,
                          Math.round(
                            (result.company.current_holdings / (result.company.required_credits || 1)) * 100
                          )
                        )}%`
                      }}
                    />
                  </div>

                  <div className="mt-2 flex justify-between text-[11px] text-slate-500 font-semibold">
                    <span>Fulfillment: {Math.round((result.company.current_holdings / (result.company.required_credits || 1)) * 100)}%</span>
                    <span>Remaining ESG Liability: {result.gap.toLocaleString()} credits</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* STEP 3: OPTIMIZED PURCHASE PLAN (if gap > 0) */}
          {result.gap > 0 && result.optimization && (
            <div className="rounded-3xl border border-sand-300 bg-white p-6 sm:p-8 shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
                <div>
                  <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-900">
                    {t('buyer.plan_title')}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 mt-0.5 font-medium">
                    {t('buyer.plan_subtitle')}
                  </p>
                </div>

                {/* Blended Quality Indicator & Total Cost Badges */}
                <div className="flex items-center gap-3 flex-wrap">
                  
                  {/* Blended Quality Score Indicator */}
                  <div className="flex items-center gap-2 rounded-2xl bg-forest-50 border border-forest-200 px-4 py-2.5">
                    <Sparkles size={18} className="text-forest-700" />
                    <div>
                      <div className="text-[10px] uppercase font-extrabold text-forest-700 tracking-wider">
                        {t('buyer.avg_quality')}
                      </div>
                      <div className="font-display text-lg font-extrabold text-forest-900">
                        {result.optimization.avg_quality_score}/100
                      </div>
                    </div>
                  </div>

                  {/* Total Estimated Cost in Active Currency */}
                  <div className="flex items-center gap-2 rounded-2xl bg-forest-950 text-white px-4 py-2.5 shadow-md border border-forest-800">
                    <TrendingUp size={18} className="text-emerald-300" />
                    <div>
                      <div className="text-[10px] uppercase font-bold text-forest-300 tracking-wider">
                        {t('buyer.total_cost')}
                      </div>
                      <div className="font-display text-lg font-extrabold text-white">
                        {formatPrice(result.optimization.total_cost)}
                      </div>
                    </div>
                  </div>

                </div>
              </div>

              {/* Selected Listings Cards Grid */}
              <div className="space-y-4">
                {(result.optimization.selected_listings || []).map((item, idx) => (
                  <div
                    key={item.id || idx}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-5 sm:p-6 rounded-2xl border border-sand-300 bg-sand-50/40 hover:bg-white hover:border-forest-400 transition-all gap-4 shadow-sm"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                        <span className="text-[11px] font-extrabold uppercase tracking-wider text-forest-900 bg-forest-100 px-2.5 py-0.5 rounded-md">
                          {item.project_type}
                        </span>
                        <QualityBadge quality_badge={item.quality_badge} score={item.quality_score} size="sm" />
                      </div>

                      <h4 className="font-display font-bold text-base sm:text-lg text-slate-900">
                        {item.project_name}
                      </h4>

                      <div className="text-xs text-slate-600 mt-1 flex items-center gap-3 font-medium">
                        <span>Registry: <strong>{item.registry}</strong></span>
                        <span>•</span>
                        <span>Vintage: <strong>{item.vintage_year}</strong></span>
                      </div>

                      {/* Distinct Anomaly Badge if is_anomaly is true */}
                      {item.is_anomaly && (
                        <div className="mt-2.5">
                          <AnomalyBadge riskScore={item.anomaly_risk_score} compact={true} />
                        </div>
                      )}
                    </div>

                    {/* Allocation and Price Columns */}
                    <div className="flex items-center justify-between sm:justify-end gap-6 border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-200">
                      <div className="text-left sm:text-right">
                        <div className="text-xs font-bold text-slate-500">{t('buyer.credits_allocated')}</div>
                        <div className="font-display text-base sm:text-lg font-bold text-slate-900">
                          {(item.credits_taken || 0).toLocaleString()} t
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-xs font-bold text-slate-500">{t('buyer.unit_price')}</div>
                        <div className="font-display text-base sm:text-lg font-extrabold text-forest-900">
                          {formatPrice(item.fair_price)}
                          <span className="text-xs font-sans font-normal text-slate-500">/t</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* STEP 4: PROCEED TO PURCHASE BUTTON */}
              <div className="mt-8 pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-xs text-slate-600 font-medium">
                  Total fulfillment: <strong>{result.optimization.total_credits_filled.toLocaleString()}</strong> of {result.gap.toLocaleString()} tCO2e required credits.
                </div>

                <button
                  type="button"
                  onClick={() => setShowCheckoutModal(true)}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-2xl bg-forest-800 px-8 py-4 text-base font-extrabold text-white shadow-xl shadow-forest-950/20 hover:bg-forest-900 hover:scale-[1.01] transition-all"
                >
                  <ShoppingBag size={19} />
                  <span>{t('buyer.proceed_btn')}</span>
                </button>
              </div>

            </div>
          )}
        </motion.div>
      )}

      {/* STEP 4: HONEST CHECKOUT PLACEHOLDER MODAL */}
      <AnimatePresence>
        {showCheckoutModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCheckoutModal(false)}
              className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm"
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-md rounded-3xl bg-white p-6 sm:p-8 shadow-2xl z-10 border border-sand-300 text-center"
            >
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-forest-100 text-forest-800 mb-4">
                <ShoppingBag size={28} />
              </div>

              <h3 className="font-display text-2xl font-bold text-slate-900">
                {t('buyer.checkout_modal_title')}
              </h3>

              <p className="mt-3 text-sm text-slate-600 leading-relaxed font-medium">
                {t('buyer.checkout_modal_desc')}
              </p>

              <div className="mt-4 p-3.5 rounded-2xl bg-sand-50 border border-sand-200 text-xs text-slate-600 font-medium">
                {t('buyer.checkout_modal_note')}
              </div>

              <div className="mt-6">
                <button
                  type="button"
                  onClick={() => setShowCheckoutModal(false)}
                  className="w-full rounded-2xl bg-forest-800 py-3.5 text-sm font-bold text-white hover:bg-forest-900 transition-colors shadow-sm"
                >
                  {t('buyer.checkout_close')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
