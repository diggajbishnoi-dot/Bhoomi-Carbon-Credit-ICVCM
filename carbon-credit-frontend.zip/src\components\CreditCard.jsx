import React from 'react';
import { motion } from 'framer-motion';
import { Award, Calendar, Database, ArrowRight, Layers, Sparkles } from 'lucide-react';
import QualityBadge from './QualityBadge';
import AnomalyBadge from './AnomalyBadge';
import { useTranslation } from '../i18n/I18nContext';
import { useCurrency } from '../utils/currency';

export default function CreditCard({ listing, onSelect, index = 0 }) {
  const { t } = useTranslation();
  const { formatPrice } = useCurrency();

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: Math.min(index * 0.05, 0.4) }}
      whileHover={{ y: -5, transition: { duration: 0.2 } }}
      onClick={() => onSelect && onSelect(listing)}
      className="group relative flex flex-col justify-between rounded-3xl border border-sand-300 bg-white p-5 sm:p-6 shadow-sm hover:shadow-xl hover:border-forest-400 transition-all cursor-pointer overflow-hidden"
    >
      {/* Top Banner: Category & Quality Indicator */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className="inline-flex items-center gap-1 text-[11px] font-extrabold uppercase tracking-wider text-forest-900 bg-forest-50 px-3 py-1 rounded-lg border border-forest-200">
            <Layers size={12} />
            {listing.project_type}
          </span>
          <QualityBadge
            quality_badge={listing.quality_badge}
            score={listing.quality_score}
            size="sm"
          />
        </div>

        {/* Project Title */}
        <h3 className="font-display text-lg font-bold text-slate-900 group-hover:text-forest-900 transition-colors line-clamp-2 mb-2 leading-snug">
          {listing.project_name}
        </h3>

        {/* Anomaly Badge if flagged */}
        {listing.is_anomaly && (
          <div className="mb-3">
            <AnomalyBadge riskScore={listing.anomaly_risk_score} compact={true} />
          </div>
        )}

        {/* Metadata Details */}
        <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 py-3 border-y border-slate-100 my-3 font-medium">
          <div className="flex items-center gap-1.5 truncate" title={listing.registry}>
            <Database size={13} className="text-forest-600 flex-shrink-0" />
            <span className="truncate">{listing.registry}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <Calendar size={13} className="text-forest-600 flex-shrink-0" />
            <span>Vintage: <strong>{listing.vintage_year}</strong></span>
          </div>

          <div className="flex items-center gap-1.5">
            <Award size={13} className="text-forest-600 flex-shrink-0" />
            <span className="capitalize font-semibold">{listing.verification_status}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Vol:</span>
            <span className="font-bold">{(listing.credits_issued || 0).toLocaleString()} t</span>
          </div>
        </div>
      </div>

      {/* Bottom Section: Price Discovery in INR/USD */}
      <div className="mt-2 pt-2 flex items-center justify-between">
        <div>
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">
            Fair Market Price
          </div>
          <div className="font-display text-2xl font-extrabold text-forest-900">
            {formatPrice(listing.fair_price)}
            <span className="text-xs font-sans font-normal text-slate-500 ml-1">/ tCO2e</span>
          </div>
        </div>

        <button
          type="button"
          className="inline-flex items-center gap-1 text-xs font-bold text-forest-800 group-hover:text-white transition-colors bg-forest-50 px-3.5 py-2 rounded-xl border border-forest-200 group-hover:bg-forest-800 shadow-sm"
        >
          <span>{t('browse_credits.view_details')}</span>
          <ArrowRight size={13} className="group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>

    </motion.div>
  );
}
